fx_version 'bodacious'
game 'gta5'

server_script 'yarn_builder.js'