fx_version 'bodacious'
game 'gta5'

dependency 'yarn'
server_script 'webpack_builder.js'