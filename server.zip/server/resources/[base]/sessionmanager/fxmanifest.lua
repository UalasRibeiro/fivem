fx_version "bodacious"
game "gta5"

client_script "client/empty.lua"
server_script "server/host_lock.lua"