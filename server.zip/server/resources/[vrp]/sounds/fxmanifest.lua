fx_version "bodacious"
game "gta5"

ui_page "web-side/index.html"

client_scripts {
	"client-side/*"
}

files {
	"web-side/*",
	"web-side/**/*"
}