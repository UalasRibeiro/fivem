window.CONFIG = {
	defaultTemplateId: 'default',
	defaultAltTemplateId: 'defaultAlt',
	templates: {
		'default': '{0}: {1}',
		'defaultAlt': '{0}',
		'print': '{0}',
		'example:important': '{0}'
  },
  suggestionLimit: 5,
	fadeTimeout: 5000,
	style: {
		width: '40%',
		height: '24%'
	}
};