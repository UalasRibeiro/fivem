fx_version "bodacious"
game "gta5"

client_scripts {
  '@PolyZone/client.lua',
	"@vrp/lib/utils.lua",
	"client-side/*"
}

server_scripts {
	"@vrp/lib/utils.lua",
	"server-side/*"
}