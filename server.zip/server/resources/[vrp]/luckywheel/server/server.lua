-----------------------------------------------------------------------------------------------------------------------------------------
-- VRP
-----------------------------------------------------------------------------------------------------------------------------------------
local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP")
-----------------------------------------------------------------------------------------------------------------------------------------
-- CONNECTION
-----------------------------------------------------------------------------------------------------------------------------------------
cRP = {}
Tunnel.bindInterface("luckywheel",cRP)
-----------------------------------------------------------------------------------------------------------------------------------------
-- VARIABLES
-----------------------------------------------------------------------------------------------------------------------------------------
local isRoll = false
-----------------------------------------------------------------------------------------------------------------------------------------
-- CHECKROLLING
-----------------------------------------------------------------------------------------------------------------------------------------
function cRP.checkRolling()
    local source = source
    local user_id = vRP.getUserId(source)
    if user_id then
        if vRP.paymentBank(user_id,1000) then
            return true
        end
    end
    return false
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- STARTROLLING
-----------------------------------------------------------------------------------------------------------------------------------------
RegisterServerEvent("luckywheel:startRolling")
AddEventHandler("luckywheel:startRolling", function()
    local source = source
    local user_id = vRP.getUserId(source) 
    if user_id then
        isRoll = true
        local _randomPrice = math.random(1, 100)
        if _randomPrice == 1 then
            local _subRan = math.random(1,1000)
            if _subRan <= 1 then
                _priceIndex = 19
            else
                _priceIndex = 3
            end
        elseif _randomPrice > 1 and _randomPrice <= 6 then
            _priceIndex = 12
            local _subRan = math.random(1,20)
            if _subRan <= 2 then
                _priceIndex = 12
            else
                _priceIndex = 7
            end
        elseif _randomPrice > 6 and _randomPrice <= 15 then
            local _sRan = math.random(1, 4)
            if _sRan == 1 then
                _priceIndex = 4
            elseif _sRan == 2 then
                _priceIndex = 8
            elseif _sRan == 3 then
                _priceIndex = 11
            else
                _priceIndex = 16
            end
        elseif _randomPrice > 15 and _randomPrice <= 25 then

            local _subRan = math.random(1,20)
            if _subRan <= 2 then
                _priceIndex = 5
            else
                _priceIndex = 20
            end
        elseif _randomPrice > 25 and _randomPrice <= 40 then
            local _sRan = math.random(1, 4)
            if _sRan == 1 then
                _priceIndex = 1
            elseif _sRan == 2 then
                _priceIndex = 9
            elseif _sRan == 3 then
                _priceIndex = 13
            else
                _priceIndex = 17
            end
        elseif _randomPrice > 40 and _randomPrice <= 60 then
            local _itemList = {}
            _itemList[1] = 2
            _itemList[2] = 6
            _itemList[3] = 10
            _itemList[4] = 14
            _itemList[5] = 18
            _priceIndex = _itemList[math.random(1, 5)]
        elseif _randomPrice > 60 and _randomPrice <= 100 then
            local _itemList = {}
            _itemList[1] = 3
            _itemList[2] = 7
            _itemList[3] = 15
            _itemList[4] = 20
            _priceIndex = _itemList[math.random(1, 4)]
        end
        SetTimeout(12000, function()
            isRoll = false
            if _priceIndex == 1 or _priceIndex == 9 or _priceIndex == 13 or _priceIndex == 17 then
                vRP.giveInventoryItem(user_id, "mask", 1,true)
                vRP.giveInventoryItem(user_id, "gloves", 1,true)
            elseif _priceIndex == 2 or _priceIndex == 6 or _priceIndex == 10 or _priceIndex == 14 or _priceIndex == 18 then
                vRP.giveInventoryItem(user_id,"bread", 1,true)
                vRP.giveInventoryItem(user_id,"water", 1,true)
            elseif _priceIndex == 3 or _priceIndex == 7 or _priceIndex == 15 or _priceIndex == 20 then
                local _money = 0
                if _priceIndex == 3 then
                    _money = 20000
                elseif _priceIndex == 7 then
                    _money = 30000
                elseif _priceIndex == 15 then
                    _money = 40000
                elseif _priceIndex == 20 then
                    _money = 50000
                end
                vRP.giveInventoryItem(user_id,"dollars",_money,true)
            elseif _priceIndex == 4 or _priceIndex == 8 or _priceIndex == 11 or _priceIndex == 16 then
                local _blackMoney = 0
                if _priceIndex == 4 then
                    _blackMoney = 10000
                elseif _priceIndex == 8 then
                    _blackMoney = 15000
                elseif _priceIndex == 11 then
                    _blackMoney = 20000
                elseif _priceIndex == 16 then
                    _blackMoney = 25000
                end
                vRP.giveInventoryItem(user_id,"dollarsz",_blackMoney * 10,true)
            elseif _priceIndex == 5 then
                vRP.giveInventoryItem(user_id,"dollars",300000,true)
            elseif _priceIndex == 12 then
                vRP.giveInventoryItem(user_id,"goldbar",1,true)
            elseif _priceIndex == 19 then
                vRP.execute("vRP/add_vehicle",{ user_id = parseInt(user_id), vehicle = "adder", plate = vRP.generatePlateNumber(), phone = vRP.getPhone(user_id), work = tostring(false) })
            end
        end)
        TriggerClientEvent("luckywheel:startRoll", -1, _priceIndex)
    end
end)