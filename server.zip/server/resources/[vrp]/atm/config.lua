cATM = { }

cATM.atmsacar = "" -- Webhook: Sacar.
cATM.atmdeposito = "" -- Webhook: Trans.

cATM.icon = 'https://media.discordapp.net/attachments/816604994690088961/846995875473522718/server.png'
cATM.bottomText = ' VRP ATM  - '
cATM.webhookColor = 16431885

-----------------------------------------------------------------------------------------------------------------------------------------
-- ATMOBJECTS
-----------------------------------------------------------------------------------------------------------------------------------------
cATM.atmObjects = {
	"prop_atm_01",
	"prop_atm_02",
	"prop_atm_03",
	"prop_fleeca_atm"
}