fx_version "adamant"
game "gta5"

client_scripts {
	"@vrp/lib/utils.lua",
	"config/config.lua",
	"client-side/*.lua"
}

server_scripts {
	"@vrp/lib/utils.lua",
	"config/config.lua",
	"server-side/*.lua"
} 