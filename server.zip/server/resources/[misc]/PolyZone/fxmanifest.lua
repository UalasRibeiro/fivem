games {'gta5'}

fx_version 'bodacious'

client_scripts {
	'client.lua',
	'BoxZone.lua',
	'EntityZone.lua',
	'CircleZone.lua',
	'ComboZone.lua'
	--'creation/*.lua'
}

server_scripts {
	'creation_sv.lua',
	'server.lua'
}