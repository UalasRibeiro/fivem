fx_version "bodacious"
game "gta5"

client_scripts {
	"client-side/*"
}

server_scripts {
	"server-side/*"
}